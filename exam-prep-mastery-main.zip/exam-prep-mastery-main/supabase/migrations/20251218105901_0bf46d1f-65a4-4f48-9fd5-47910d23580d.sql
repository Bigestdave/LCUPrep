-- Clear all data from profiles and purchases tables
TRUNCATE TABLE public.purchases;
TRUNCATE TABLE public.profiles;