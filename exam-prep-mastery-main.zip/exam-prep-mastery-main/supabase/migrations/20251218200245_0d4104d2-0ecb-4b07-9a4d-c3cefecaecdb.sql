INSERT INTO public.user_roles (user_id, role) 
VALUES ('0e177407-4537-4dc2-b906-9c01a38dcbc6', 'admin');